public abstract class Oviparous extends Animal {

    /* Oviparous constructor */
    public Oviparous(boolean mammals, boolean carnivorous, int mood) {
        super(mammals, carnivorous, mood);
    }
}
