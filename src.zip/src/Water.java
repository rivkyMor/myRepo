public interface Water {
    boolean hasGills();

    boolean hasLayEggs();
}
