public class TestAnimal {

    public static void main(String[] args) {
        Animal animal = new Dog(Animal.MOOD_HAPPY);
        Animal animal2 = new Cat(Animal.MOOD_SCARE);
        Animal animal3 = new Frog(true, true, Animal.MOOD_HAPPY);

        animal3.sayHello();

    }
}
