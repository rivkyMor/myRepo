public interface Land {
    int getNumberOfLegs();
}
