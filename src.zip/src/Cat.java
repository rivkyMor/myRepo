public class Cat extends Animal implements Land {


    /* Cat properties */
    private int numberOfLegs = 4;

    /* Cat constructor */
    public Cat(int mood) {
        super(true, true, mood);
    }

    /* Cat methods  */
    @Override
    public void sayHello(int mood) {
        if (mood == MOOD_HAPPY) {
            purr();
        } else if (mood == MOOD_SCARE) {
            hiss();
        }
    }

    @Override
    public void sayHello() {
        meow();
    }

    @Override
    public int getNumberOfLegs() {
        return numberOfLegs;
    }

    public void meow() {
        System.out.println("meow~");
    }

    public void purr() {
        System.out.println("purr,purr");
    }

    public void hiss() {
        System.out.println("hiss");
    }

}
