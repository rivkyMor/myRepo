public class Frog extends Oviparous implements Land, Water {

    /* Frog properties */
    private int numberOfLegs = 4;

    /* Frog constructor */
    public Frog(boolean mammals, boolean carnivorous, int mood) {
        super(mammals, carnivorous, mood);
    }


    /* Frog methods */
    @Override
    public void sayHello(int mood) {
        if (mood == MOOD_HAPPY) {
            quack();
        } else if (mood == MOOD_SCARE) {
            plop();
        }
    }

    @Override
    public int getNumberOfLegs() {
        return numberOfLegs;
    }

    @Override
    public boolean hasGills() {
        return false;
    }

    @Override
    public boolean hasLayEggs() {
        return false;
    }

    public void quack() {
        System.out.println("Quack!");
    }

    public void plop() {
        System.out.println("*Plop into the water*");
    }

}
