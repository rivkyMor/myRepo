public class Dog extends Animal implements Land {


    /* Dog properties */
    private int numberOfLegs = 4;

    /* Dog constructor */
    public Dog(int mood) {
        super(true, true, mood);
    }

    /* Dog methods  */
    @Override
    public void sayHello(int mood) {
        if (mood == MOOD_HAPPY) {
            bark();
        } else if (mood == MOOD_SCARE) {
            whoop();
        }
    }

    @Override
    public void sayHello() {
        wagTail(); // usually greet people by wagging tale
    }

    @Override
    public int getNumberOfLegs() {
        return numberOfLegs;
    }

    public void wagTail() {
        System.out.println("*wagging tail*");
    }

    public void bark() {
        System.out.println("How How!");
    }

    public void whoop() {
        System.out.println("Whoop!");
    }
}
